"use client";

import { AuthLayout } from "@/components/auth/AuthLayout";

export default function RegisterPage() {
  return <AuthLayout initialMode="signup" />;
}

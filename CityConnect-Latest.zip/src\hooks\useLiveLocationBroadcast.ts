"use client";

import { useEffect, useRef, useState } from "react";
import { BookingStatus } from "@/types/provider";
import { getSocket } from "@/lib/socket";

const ACTIVE_TRACKING_STATUSES: (BookingStatus | string)[] = ["Accepted", "OnTheWay", "Started"];

// Haversine formula to compute distance in meters between two lat/lng pairs
function getHaversineDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371e3; // metres
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

export interface LiveLocationPosition {
  latitude: number;
  longitude: number;
  accuracy?: number | null;
  heading?: number | null;
  speed?: number | null;
  timestamp: number;
}

export function useLiveLocationBroadcast(
  bookingId: string | null | undefined,
  status: BookingStatus | string | null | undefined,
  role: "provider" | "customer" = "provider",
  enabled: boolean = true
) {
  const [isTracking, setIsTracking] = useState(false);
  const [lastPosition, setLastPosition] = useState<LiveLocationPosition | null>(null);
  const [accuracy, setAccuracy] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const lastSentPositionRef = useRef<{ lat: number; lng: number; time: number } | null>(null);
  const watchIdRef = useRef<number | null>(null);

  useEffect(() => {
    const isWindowActive = Boolean(
      enabled && bookingId && status && ACTIVE_TRACKING_STATUSES.includes(status)
    );

    // Stop tracking immediately if disabled or outside active window
    if (!isWindowActive) {
      if (watchIdRef.current !== null && typeof navigator !== "undefined" && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      setIsTracking(false);
      return;
    }

    if (typeof window === "undefined" || !navigator.geolocation) {
      setError("Geolocation is not supported by this browser");
      return;
    }

    setIsTracking(true);
    setError(null);

    const socket = getSocket();

    const handleSuccess = (pos: GeolocationPosition) => {
      const { latitude, longitude, heading, speed, accuracy: rawAccuracy } = pos.coords;
      const now = Date.now();

      setAccuracy(rawAccuracy ?? null);

      // Ignore extremely inaccurate reading (> 150m) to prevent erratic marker jumps
      if (typeof rawAccuracy === "number" && rawAccuracy > 150) {
        console.warn(`[Location Broadcast] Inaccurate reading rejected (${rawAccuracy}m accuracy)`);
        return;
      }

      const newPos: LiveLocationPosition = {
        latitude,
        longitude,
        accuracy: rawAccuracy ?? null,
        heading: heading ?? null,
        speed: speed ?? null,
        timestamp: now
      };

      setLastPosition(newPos);

      // High-precision tracking broadcast: send if moved >3m OR at least 2.5 seconds elapsed
      let shouldSend = false;

      if (!lastSentPositionRef.current) {
        shouldSend = true;
      } else {
        const timeElapsedMs = now - lastSentPositionRef.current.time;
        const distMeters = getHaversineDistanceMeters(
          lastSentPositionRef.current.lat,
          lastSentPositionRef.current.lng,
          latitude,
          longitude
        );

        if (distMeters >= 3 || timeElapsedMs >= 2500) {
          shouldSend = true;
        }
      }

      if (shouldSend) {
        lastSentPositionRef.current = { lat: latitude, lng: longitude, time: now };

        const payload = {
          bookingId,
          latitude,
          longitude,
          accuracy: rawAccuracy ?? null,
          heading: heading ?? null,
          speed: speed ?? null,
          timestamp: now
        };

        // (a) Emit Socket.IO event for real-time tracking
        if (socket && socket.connected) {
          if (role === "provider") {
            socket.emit("provider:location:update", payload);
            socket.emit("location:update", payload);
          } else {
            socket.emit("customer:location:update", payload);
          }
        }

        // (b) REST POST to persist last-known position fire-and-forget
        const token = typeof window !== "undefined" ? localStorage.getItem("cityconnect_auth_token") : null;
        const userId = typeof window !== "undefined" ? localStorage.getItem("cityconnect_user_id") : null;
        const headers: Record<string, string> = {
          "Content-Type": "application/json"
        };
        if (token) headers["Authorization"] = `Bearer ${token}`;
        if (userId) headers["x-user-id"] = userId;

        const endpoint = role === "provider" 
          ? `/api/bookings/${bookingId}/provider-location` 
          : `/api/bookings/${bookingId}/customer-location`;

        fetch(endpoint, {
          method: "POST",
          headers,
          body: JSON.stringify({ latitude, longitude, accuracy: rawAccuracy ?? null })
        }).catch((err) => console.warn("[Location Broadcast] REST POST error:", err));
      }
    };

    const handleError = (err: GeolocationPositionError) => {
      console.warn(`[Location Broadcast] Geolocation error (${err.code}): ${err.message}`);
      let userMsg = err.message;
      if (err.code === err.PERMISSION_DENIED) {
        userMsg = "Location permission denied. Please allow location access to share your live location.";
      } else if (err.code === err.POSITION_UNAVAILABLE) {
        userMsg = "Unable to determine your current location. Please check device GPS settings.";
      } else if (err.code === err.TIMEOUT) {
        userMsg = "Location request timed out. Retrying...";
      }
      setError(userMsg);
    };

    watchIdRef.current = navigator.geolocation.watchPosition(
      handleSuccess,
      handleError,
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 5000
      }
    );

    return () => {
      if (watchIdRef.current !== null && typeof navigator !== "undefined" && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      setIsTracking(false);
    };
  }, [bookingId, status, role, enabled]);

  return { isTracking, lastPosition, accuracy, error };
}

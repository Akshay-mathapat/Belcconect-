"use client";

import { useEffect, useState } from "react";
import { Joyride, EventData, STATUS, Step } from "react-joyride";
import { useAuthStore } from "@/store/useAuthStore";

export function ProviderTour() {
  const { currentUser, dismissTour } = useAuthStore();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted || !currentUser || currentUser.isFirstLogin === false) {
    return null;
  }

  const steps: Step[] = [
    {
      target: '[data-tour="provider-dashboard"]',
      title: "📊 Provider Command Center",
      content: "Overview of your active bookings, earnings analytics, quick stats, and performance metrics.",
      placement: "right",
    },
    {
      target: '[data-tour="add-service"]',
      title: "🛠️ List Your Services",
      content: "Click here to offer a new service, set descriptions, select taxonomy categories, and define service rates.",
      placement: "right",
    },
    {
      target: '[data-tour="provider-availability"]',
      title: "⏰ Set Working Hours",
      content: "Configure your active working days, morning/evening shifts, and toggle instant availability.",
      placement: "right",
    },
    {
      target: '[data-tour="provider-bookings"]',
      title: "📋 Manage Job Requests & GPS",
      content: "Accept incoming customer bookings, communicate via voice/chat, update status (On The Way / Started), and share live GPS tracking.",
      placement: "right",
    },
    {
      target: "#tour-provider-kyc",
      title: "🛡️ Verified Badge & Profile",
      content: "Keep your profile picture, bio, skills, and spoken languages up-to-date to gain customer trust.",
      placement: "top",
    },
  ];

  const handleJoyrideCallback = (data: EventData) => {
    const { status } = data;
    const finishedStatuses: string[] = [STATUS.FINISHED, STATUS.SKIPPED];
    if (finishedStatuses.includes(status)) {
      dismissTour();
    }
  };

  return (
    <Joyride
      steps={steps}
      run={true}
      continuous={true}
      onEvent={handleJoyrideCallback}
      locale={{
        back: "Back",
        close: "Close",
        last: "Finish Tour 🎉",
        next: "Next →",
        skip: "Skip",
      }}
      options={{
        arrowColor: "#1e293b",
        backgroundColor: "#0f172a",
        overlayColor: "rgba(15, 23, 42, 0.75)",
        primaryColor: "#2563eb",
        textColor: "#f8fafc",
        zIndex: 10000,
        skipBeacon: true,
        showProgress: true,
        buttons: ["back", "skip", "primary"],
        overlayClickAction: false,
      }}
      styles={{
        tooltip: {
          borderRadius: "20px",
          border: "1px solid rgba(59, 130, 246, 0.3)",
          padding: "22px",
          boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.6), 0 0 20px rgba(37, 99, 235, 0.2)",
          backgroundColor: "#0f172a",
        },
        tooltipContainer: {
          textAlign: "left",
        },
        tooltipTitle: {
          fontSize: "17px",
          fontWeight: "800",
          color: "#ffffff",
          marginBottom: "8px",
          display: "flex",
          alignItems: "center",
          gap: "8px",
        },
        tooltipContent: {
          fontSize: "13.5px",
          color: "#94a3b8",
          lineHeight: "1.6",
          padding: "4px 0 14px 0",
        },
        buttonPrimary: {
          backgroundColor: "#2563eb",
          borderRadius: "12px",
          color: "#ffffff",
          fontSize: "12px",
          fontWeight: "700",
          padding: "10px 18px",
          outline: "none",
          boxShadow: "0 4px 12px rgba(37, 99, 235, 0.4)",
          transition: "all 0.2s ease",
        },
        buttonBack: {
          color: "#94a3b8",
          fontSize: "12px",
          fontWeight: "600",
          marginRight: "10px",
        },
        buttonSkip: {
          color: "#64748b",
          fontSize: "12px",
          fontWeight: "600",
        },
      }}
    />
  );
}

